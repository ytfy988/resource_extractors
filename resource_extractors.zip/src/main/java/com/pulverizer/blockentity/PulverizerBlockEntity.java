package com.pulverizer.blockentity;

import com.pulverizer.PulverizerMod;
import com.pulverizer.block.PulverizerBlock;
import com.pulverizer.screen.PulverizerScreenHandler;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class PulverizerBlockEntity extends BlockEntity implements NamedScreenHandlerFactory, SidedInventory {
    private final DefaultedList<ItemStack> inventory = DefaultedList.ofSize(3, ItemStack.EMPTY);
    
    public static final int INPUT_SLOT = 0;
    public static final int FUEL_SLOT = 1;
    public static final int OUTPUT_SLOT = 2;
    
    // Hopper slot access - like furnace
    private static final int[] TOP_SLOTS = {INPUT_SLOT};
    private static final int[] BOTTOM_SLOTS = {OUTPUT_SLOT, FUEL_SLOT};
    private static final int[] SIDE_SLOTS = {FUEL_SLOT};
    
    private int burnTime = 0;
    private int fuelTime = 0;
    private int progress = 0;
    private int maxProgress = 200; // 10 seconds at 20 ticks/sec
    
    // Top frame tracking - persists between processing cycles
    private int topFrame = 1; // 1-4, saved to NBT
    private int frameTimer = 0; // Timer for cycling frames
    private static final int FRAME_CYCLE_TICKS = 10; // Cycle frame every 10 ticks (0.5 sec)
    
    // Experience tracking
    private float storedExperience = 0;
    
    protected final PropertyDelegate propertyDelegate = new PropertyDelegate() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> burnTime;
                case 1 -> fuelTime;
                case 2 -> progress;
                case 3 -> maxProgress;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> burnTime = value;
                case 1 -> fuelTime = value;
                case 2 -> progress = value;
                case 3 -> maxProgress = value;
            }
        }

        @Override
        public int size() {
            return 4;
        }
    };

    public PulverizerBlockEntity(BlockPos pos, BlockState state) {
        super(PulverizerMod.PULVERIZER_BLOCK_ENTITY, pos, state);
    }

    @Override
    public Text getDisplayName() {
        return Text.translatable("block.pulverizer.pulverizer");
    }

    @Nullable
    @Override
    public ScreenHandler createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
        return new PulverizerScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        Inventories.writeNbt(nbt, inventory, registryLookup);
        nbt.putInt("BurnTime", burnTime);
        nbt.putInt("FuelTime", fuelTime);
        nbt.putInt("Progress", progress);
        nbt.putInt("TopFrame", topFrame);
        nbt.putFloat("StoredExperience", storedExperience);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        Inventories.readNbt(nbt, inventory, registryLookup);
        burnTime = nbt.getInt("BurnTime");
        fuelTime = nbt.getInt("FuelTime");
        progress = nbt.getInt("Progress");
        topFrame = nbt.getInt("TopFrame");
        storedExperience = nbt.getFloat("StoredExperience");
        if (topFrame < 1 || topFrame > 4) {
            topFrame = 1; // Default to frame 1 if invalid
        }
    }

    public void tick(World world, BlockPos pos, BlockState state) {
        if (world.isClient) return;

        boolean wasLit = state.get(PulverizerBlock.LIT);
        boolean dirty = false;
        boolean isCurrentlyProcessing = false;

        if (burnTime > 0) {
            burnTime--;
        }

        ItemStack fuelStack = inventory.get(FUEL_SLOT);

        if (canProcess()) {
            if (burnTime <= 0 && isValidFuel(fuelStack)) {
                burnTime = getFuelTime(fuelStack);
                fuelTime = burnTime;
                if (burnTime > 0) {
                    dirty = true;
                    if (!fuelStack.isEmpty()) {
                        ItemStack remainder = fuelStack.getRecipeRemainder();
                        fuelStack.decrement(1);
                        if (fuelStack.isEmpty() && !remainder.isEmpty()) {
                            inventory.set(FUEL_SLOT, remainder);
                        }
                    }
                }
            }

            if (burnTime > 0) {
                isCurrentlyProcessing = true;
                progress++;
                
                // Cycle top frame while processing
                frameTimer++;
                if (frameTimer >= FRAME_CYCLE_TICKS) {
                    frameTimer = 0;
                    int oldFrame = topFrame;
                    topFrame++;
                    if (topFrame > 4) {
                        topFrame = 1;
                    }
                    // Update block state if frame changed
                    if (oldFrame != topFrame) {
                        world.setBlockState(pos, state.with(PulverizerBlock.TOP_FRAME, topFrame), 3);
                        state = world.getBlockState(pos); // Get updated state
                    }
                }
                
                if (progress >= maxProgress) {
                    processItem();
                    progress = 0;
                }
                dirty = true;
            }
        } else {
            if (progress > 0) {
                progress = 0;
                dirty = true;
            }
            // Reset frame timer when not processing (but keep topFrame as-is for persistence)
            frameTimer = 0;
        }

        // Sound is handled client-side via PulverizerSoundManager
        // LIT = true only when actively processing (has fuel burning AND items to process)
        if (wasLit != isCurrentlyProcessing) {
            state = state.with(PulverizerBlock.LIT, isCurrentlyProcessing);
            world.setBlockState(pos, state, 3);
            dirty = true;
        }
        
        // Ensure TOP_FRAME is synced with block state
        int currentStateFrame = state.get(PulverizerBlock.TOP_FRAME);
        if (currentStateFrame != topFrame) {
            world.setBlockState(pos, state.with(PulverizerBlock.TOP_FRAME, topFrame), 3);
        }

        if (dirty) {
            markDirty();
        }
    }

    private boolean canProcess() {
        ItemStack input = inventory.get(INPUT_SLOT);
        if (input.isEmpty()) return false;

        ItemStack result = getResult(input);
        if (result.isEmpty()) return false;

        ItemStack output = inventory.get(OUTPUT_SLOT);
        if (output.isEmpty()) return true;
        if (!ItemStack.areItemsEqual(output, result)) return false;
        return output.getCount() + result.getCount() <= output.getMaxCount();
    }

    private void processItem() {
        ItemStack input = inventory.get(INPUT_SLOT);
        ItemStack result = getResult(input);
        ItemStack output = inventory.get(OUTPUT_SLOT);

        if (output.isEmpty()) {
            inventory.set(OUTPUT_SLOT, result.copy());
        } else if (ItemStack.areItemsEqual(output, result)) {
            output.increment(result.getCount());
        }

        // Add experience for processing
        storedExperience += getExperience(input);
        
        input.decrement(1);
    }

    private ItemStack getResult(ItemStack input) {
        if (input.isOf(Items.STONE)) {
            return new ItemStack(Items.COBBLESTONE);
        } else if (input.isOf(Items.COBBLESTONE)) {
            return new ItemStack(Items.GRAVEL, 2);
        } else if (input.isOf(Items.GRAVEL)) {
            return new ItemStack(Items.FLINT, 4);
        } else if (input.isOf(Items.FLINT)) {
            return new ItemStack(PulverizerMod.SAND_DUST, 1);
        } else if (input.isOf(Items.RAW_IRON)) {
            return new ItemStack(PulverizerMod.RAW_IRON_DUST, 2);
        } else if (input.isOf(Items.RAW_GOLD)) {
            return new ItemStack(PulverizerMod.RAW_GOLD_DUST, 2);
        } else if (input.isOf(Items.RAW_COPPER)) {
            return new ItemStack(PulverizerMod.RAW_COPPER_DUST, 2);
        }
        return ItemStack.EMPTY;
    }
    
    // Experience values (similar to furnace smelting)
    // Clay ball -> brick = 0.3 XP
    private float getExperience(ItemStack input) {
        if (input.isOf(Items.STONE) || input.isOf(Items.COBBLESTONE) || 
            input.isOf(Items.GRAVEL) || input.isOf(Items.FLINT)) {
            return 0.1f; // Small XP for stone processing
        } else if (input.isOf(Items.RAW_IRON) || input.isOf(Items.RAW_GOLD) || 
                   input.isOf(Items.RAW_COPPER)) {
            return 0.7f; // Same as smelting ore
        }
        return 0.0f;
    }
    
    // Called when player takes items from output slot
    public void dropExperience(ServerWorld world, Vec3d pos) {
        if (storedExperience > 0) {
            int xpAmount = (int) storedExperience;
            float remainder = storedExperience - xpAmount;
            
            // Random chance for the remainder
            if (remainder > 0 && world.random.nextFloat() < remainder) {
                xpAmount++;
            }
            
            if (xpAmount > 0) {
                ExperienceOrbEntity.spawn(world, pos, xpAmount);
            }
            storedExperience = 0;
        }
    }
    
    public float getStoredExperience() {
        return storedExperience;
    }

    private boolean isValidFuel(ItemStack stack) {
        return getFuelTime(stack) > 0;
    }

    private int getFuelTime(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        Integer fuelTime = FuelRegistry.INSTANCE.get(stack.getItem());
        return fuelTime != null ? fuelTime : 0;
    }
    
    public static boolean isValidInput(ItemStack stack) {
        return stack.isOf(Items.STONE) || stack.isOf(Items.COBBLESTONE) || stack.isOf(Items.GRAVEL)
                || stack.isOf(Items.FLINT)
                || stack.isOf(Items.RAW_IRON) || stack.isOf(Items.RAW_GOLD) || stack.isOf(Items.RAW_COPPER);
    }

    // ---- SidedInventory Implementation for Hoppers ----
    
    @Override
    public int[] getAvailableSlots(Direction side) {
        if (side == Direction.DOWN) {
            return BOTTOM_SLOTS;
        } else if (side == Direction.UP) {
            return TOP_SLOTS;
        } else {
            return SIDE_SLOTS;
        }
    }

    @Override
    public boolean canInsert(int slot, ItemStack stack, @Nullable Direction dir) {
        if (slot == OUTPUT_SLOT) {
            return false;
        } else if (slot == FUEL_SLOT) {
            return isValidFuel(stack) || stack.isOf(Items.BUCKET);
        } else if (slot == INPUT_SLOT) {
            return isValidInput(stack);
        }
        return false;
    }

    @Override
    public boolean canExtract(int slot, ItemStack stack, Direction dir) {
        if (slot == FUEL_SLOT) {
            return stack.isOf(Items.BUCKET);
        }
        return slot == OUTPUT_SLOT;
    }

    // ---- Inventory Implementation ----

    @Override
    public int size() {
        return inventory.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : inventory) {
            if (!stack.isEmpty()) return false;
        }
        return true;
    }

    @Override
    public ItemStack getStack(int slot) {
        return inventory.get(slot);
    }

    @Override
    public ItemStack removeStack(int slot, int amount) {
        return Inventories.splitStack(inventory, slot, amount);
    }

    @Override
    public ItemStack removeStack(int slot) {
        return Inventories.removeStack(inventory, slot);
    }

    @Override
    public void setStack(int slot, ItemStack stack) {
        inventory.set(slot, stack);
        if (stack.getCount() > getMaxCountPerStack()) {
            stack.setCount(getMaxCountPerStack());
        }
        markDirty();
    }

    @Override
    public boolean canPlayerUse(PlayerEntity player) {
        return Inventory.canPlayerUse(this, player);
    }

    @Override
    public void clear() {
        inventory.clear();
    }
}

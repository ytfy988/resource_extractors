package com.pulverizer.blockentity;

import com.pulverizer.PulverizerMod;
import com.pulverizer.block.AlloyForgeBlock;
import com.pulverizer.screen.AlloyForgeScreenHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class AlloyForgeBlockEntity extends BlockEntity implements NamedScreenHandlerFactory, SidedInventory {
    private final DefaultedList<ItemStack> inventory = DefaultedList.ofSize(3, ItemStack.EMPTY);
    
    public static final int INPUT_SLOT = 0;
    public static final int FUEL_SLOT = 1;
    public static final int OUTPUT_SLOT = 2;
    
    // Hopper slot access
    private static final int[] TOP_SLOTS = {INPUT_SLOT};
    private static final int[] BOTTOM_SLOTS = {OUTPUT_SLOT, FUEL_SLOT};
    private static final int[] SIDE_SLOTS = {FUEL_SLOT};
    
    private int burnTime = 0;
    private int fuelTime = 0;
    private int progress = 0;
    private int maxProgress = 1200; // 60 seconds at 20 ticks/sec
    
    // Experience tracking
    private float storedExperience = 0;
    
    protected final PropertyDelegate propertyDelegate = new PropertyDelegate() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> burnTime;
                case 1 -> fuelTime;
                case 2 -> progress;
                case 3 -> maxProgress;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> burnTime = value;
                case 1 -> fuelTime = value;
                case 2 -> progress = value;
                case 3 -> maxProgress = value;
            }
        }

        @Override
        public int size() {
            return 4;
        }
    };

    public AlloyForgeBlockEntity(BlockPos pos, BlockState state) {
        super(PulverizerMod.ALLOY_FORGE_BLOCK_ENTITY, pos, state);
    }

    @Override
    public Text getDisplayName() {
        return Text.translatable("block.pulverizer.alloy_forge");
    }

    @Nullable
    @Override
    public ScreenHandler createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
        return new AlloyForgeScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        Inventories.writeNbt(nbt, inventory, registryLookup);
        nbt.putInt("BurnTime", burnTime);
        nbt.putInt("FuelTime", fuelTime);
        nbt.putInt("Progress", progress);
        nbt.putFloat("StoredExperience", storedExperience);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        Inventories.readNbt(nbt, inventory, registryLookup);
        burnTime = nbt.getInt("BurnTime");
        fuelTime = nbt.getInt("FuelTime");
        progress = nbt.getInt("Progress");
        storedExperience = nbt.getFloat("StoredExperience");
    }

    public void tick(World world, BlockPos pos, BlockState state) {
        if (world.isClient) return;

        boolean wasBurning = burnTime > 0;
        boolean dirty = false;

        if (burnTime > 0) {
            burnTime--;
        }

        ItemStack fuelStack = inventory.get(FUEL_SLOT);

        if (canProcess()) {
            if (burnTime <= 0 && isValidFuel(fuelStack)) {
                burnTime = getFuelTime(fuelStack);
                fuelTime = burnTime;
                if (burnTime > 0) {
                    dirty = true;
                    if (!fuelStack.isEmpty()) {
                        fuelStack.decrement(1);
                    }
                }
            }

            if (burnTime > 0) {
                progress++;
                
                if (progress >= maxProgress) {
                    processItem();
                    progress = 0;
                }
                dirty = true;
            }
        } else {
            if (progress > 0) {
                progress = 0;
                dirty = true;
            }
        }

        // Sound is handled client-side via AlloyForgeSoundManager

        boolean isBurning = burnTime > 0;
        if (wasBurning != isBurning) {
            state = state.with(AlloyForgeBlock.LIT, isBurning);
            world.setBlockState(pos, state, 3);
            dirty = true;
        }

        if (dirty) {
            markDirty();
        }
    }

    private boolean canProcess() {
        ItemStack input = inventory.get(INPUT_SLOT);
        if (input.isEmpty()) return false;

        ItemStack result = getResult(input);
        if (result.isEmpty()) return false;

        ItemStack output = inventory.get(OUTPUT_SLOT);
        if (output.isEmpty()) return true;
        if (!ItemStack.areItemsEqual(output, result)) return false;
        return output.getCount() + result.getCount() <= output.getMaxCount();
    }

    private void processItem() {
        ItemStack input = inventory.get(INPUT_SLOT);
        ItemStack result = getResult(input);
        ItemStack output = inventory.get(OUTPUT_SLOT);

        if (output.isEmpty()) {
            inventory.set(OUTPUT_SLOT, result.copy());
        } else if (ItemStack.areItemsEqual(output, result)) {
            output.increment(result.getCount());
        }

        // Add experience - same as smelting iron ore (0.7 XP)
        storedExperience += 0.7f;
        
        input.decrement(1);
    }

    private ItemStack getResult(ItemStack input) {
        // Iron ingot -> Steel ingot
        if (input.isOf(Items.IRON_INGOT)) {
            return new ItemStack(PulverizerMod.STEEL_INGOT, 1);
        }
        return ItemStack.EMPTY;
    }
    
    // Called when player takes items from output slot
    public void dropExperience(ServerWorld world, Vec3d pos) {
        if (storedExperience > 0) {
            int xpAmount = (int) storedExperience;
            float remainder = storedExperience - xpAmount;
            
            // Random chance for the remainder
            if (remainder > 0 && world.random.nextFloat() < remainder) {
                xpAmount++;
            }
            
            if (xpAmount > 0) {
                ExperienceOrbEntity.spawn(world, pos, xpAmount);
            }
            storedExperience = 0;
        }
    }
    
    public float getStoredExperience() {
        return storedExperience;
    }

    private boolean isValidFuel(ItemStack stack) {
        // Only coal and charcoal
        return stack.isOf(Items.COAL) || stack.isOf(Items.CHARCOAL);
    }

    private int getFuelTime(ItemStack stack) {
        // Coal and charcoal burn for 1600 ticks (same as furnace)
        if (stack.isOf(Items.COAL) || stack.isOf(Items.CHARCOAL)) {
            return 1600;
        }
        return 0;
    }
    
    public static boolean isValidInput(ItemStack stack) {
        return stack.isOf(Items.IRON_INGOT);
    }

    // ---- SidedInventory Implementation for Hoppers ----
    
    @Override
    public int[] getAvailableSlots(Direction side) {
        if (side == Direction.DOWN) {
            return BOTTOM_SLOTS;
        } else if (side == Direction.UP) {
            return TOP_SLOTS;
        } else {
            return SIDE_SLOTS;
        }
    }

    @Override
    public boolean canInsert(int slot, ItemStack stack, @Nullable Direction dir) {
        if (slot == OUTPUT_SLOT) {
            return false;
        } else if (slot == FUEL_SLOT) {
            return isValidFuel(stack);
        } else if (slot == INPUT_SLOT) {
            return isValidInput(stack);
        }
        return false;
    }

    @Override
    public boolean canExtract(int slot, ItemStack stack, Direction dir) {
        return slot == OUTPUT_SLOT;
    }

    // ---- Inventory Implementation ----

    @Override
    public int size() {
        return inventory.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : inventory) {
            if (!stack.isEmpty()) return false;
        }
        return true;
    }

    @Override
    public ItemStack getStack(int slot) {
        return inventory.get(slot);
    }

    @Override
    public ItemStack removeStack(int slot, int amount) {
        return Inventories.splitStack(inventory, slot, amount);
    }

    @Override
    public ItemStack removeStack(int slot) {
        return Inventories.removeStack(inventory, slot);
    }

    @Override
    public void setStack(int slot, ItemStack stack) {
        inventory.set(slot, stack);
        if (stack.getCount() > getMaxCountPerStack()) {
            stack.setCount(getMaxCountPerStack());
        }
        markDirty();
    }

    @Override
    public boolean canPlayerUse(PlayerEntity player) {
        return Inventory.canPlayerUse(this, player);
    }

    @Override
    public void clear() {
        inventory.clear();
    }
}

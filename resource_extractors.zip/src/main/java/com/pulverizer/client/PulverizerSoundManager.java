package com.pulverizer.client;

import com.pulverizer.PulverizerMod;
import com.pulverizer.block.PulverizerBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PulverizerSoundManager {
    private static final Map<BlockPos, PulverizerSoundInstance> activeSounds = new HashMap<>();
    private static final int CHECK_RADIUS = 24; // Check for pulverizers within this radius
    private static int tickCounter = 0;
    private static final int SCAN_INTERVAL = 10; // Only do full scan every 10 ticks

    public static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            // Clear all sounds if no world
            activeSounds.clear();
            return;
        }

        tickCounter++;
        
        // Only do a full scan periodically to save performance
        if (tickCounter % SCAN_INTERVAL != 0) {
            // Just check if existing sounds should stop
            checkExistingSounds(client);
            return;
        }

        World world = client.world;
        BlockPos playerPos = client.player.getBlockPos();

        // Find all lit pulverizers nearby
        Set<BlockPos> litPulverizers = new HashSet<>();
        
        for (int x = -CHECK_RADIUS; x <= CHECK_RADIUS; x++) {
            for (int y = -CHECK_RADIUS; y <= CHECK_RADIUS; y++) {
                for (int z = -CHECK_RADIUS; z <= CHECK_RADIUS; z++) {
                    BlockPos checkPos = playerPos.add(x, y, z);
                    var state = world.getBlockState(checkPos);
                    
                    if (state.isOf(PulverizerMod.PULVERIZER_BLOCK) && state.get(PulverizerBlock.LIT)) {
                        litPulverizers.add(checkPos);
                    }
                }
            }
        }

        // Start sounds for new lit pulverizers
        for (BlockPos pos : litPulverizers) {
            if (!activeSounds.containsKey(pos)) {
                PulverizerSoundInstance sound = new PulverizerSoundInstance(world, pos);
                activeSounds.put(pos, sound);
                client.getSoundManager().play(sound);
            }
        }

        // Remove sounds for pulverizers that are no longer lit or in range
        Set<BlockPos> toRemove = new HashSet<>();
        for (Map.Entry<BlockPos, PulverizerSoundInstance> entry : activeSounds.entrySet()) {
            BlockPos pos = entry.getKey();
            PulverizerSoundInstance sound = entry.getValue();
            
            if (!litPulverizers.contains(pos) || sound.isDone()) {
                toRemove.add(pos);
            }
        }
        
        for (BlockPos pos : toRemove) {
            activeSounds.remove(pos);
        }
    }
    
    private static void checkExistingSounds(MinecraftClient client) {
        // Quick check - just verify existing sounds are still valid
        Set<BlockPos> toRemove = new HashSet<>();
        
        for (Map.Entry<BlockPos, PulverizerSoundInstance> entry : activeSounds.entrySet()) {
            PulverizerSoundInstance sound = entry.getValue();
            if (sound.isDone()) {
                toRemove.add(entry.getKey());
            }
        }
        
        for (BlockPos pos : toRemove) {
            activeSounds.remove(pos);
        }
    }

    public static void stopAll() {
        activeSounds.clear();
    }
}

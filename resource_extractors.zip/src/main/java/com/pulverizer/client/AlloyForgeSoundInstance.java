package com.pulverizer.client;

import com.pulverizer.PulverizerMod;
import com.pulverizer.block.AlloyForgeBlock;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class AlloyForgeSoundInstance extends MovingSoundInstance {
    private final World world;
    private final BlockPos pos;

    public AlloyForgeSoundInstance(World world, BlockPos pos) {
        super(SoundEvents.BLOCK_BLASTFURNACE_FIRE_CRACKLE, SoundCategory.BLOCKS, SoundInstance.createRandom());
        this.world = world;
        this.pos = pos;
        
        // Set position
        this.x = pos.getX() + 0.5;
        this.y = pos.getY() + 0.5;
        this.z = pos.getZ() + 0.5;
        
        // Sound properties
        this.repeat = true;
        this.repeatDelay = 0;
        this.volume = 1.0f;
        this.pitch = 1.0f;
        
        this.attenuationType = AttenuationType.LINEAR;
    }

    @Override
    public void tick() {
        if (world == null || !world.isClient()) {
            this.setDone();
            return;
        }
        
        var state = world.getBlockState(pos);
        if (!state.isOf(PulverizerMod.ALLOY_FORGE_BLOCK) || !state.get(AlloyForgeBlock.LIT)) {
            this.setDone();
            return;
        }
    }

    @Override
    public boolean shouldAlwaysPlay() {
        return true;
    }

    public BlockPos getPos() {
        return pos;
    }
}

package com.pulverizer.client;

import com.pulverizer.PulverizerMod;
import com.pulverizer.block.PulverizerBlock;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class PulverizerSoundInstance extends MovingSoundInstance {
    private final World world;
    private final BlockPos pos;

    public PulverizerSoundInstance(World world, BlockPos pos) {
        super(PulverizerMod.PULVERIZER_RUNNING_SOUND, SoundCategory.BLOCKS, SoundInstance.createRandom());
        this.world = world;
        this.pos = pos;
        
        // Set position
        this.x = pos.getX() + 0.5;
        this.y = pos.getY() + 0.5;
        this.z = pos.getZ() + 0.5;
        
        // Sound properties
        this.repeat = true;
        this.repeatDelay = 0;
        this.volume = 1.0f;
        this.pitch = 1.0f;
        
        // Use linear attenuation for better distance falloff
        this.attenuationType = AttenuationType.LINEAR;
    }

    @Override
    public void tick() {
        // Check if block still exists and is lit
        if (world == null || !world.isClient()) {
            this.setDone();
            return;
        }
        
        // Check if the block is still a lit pulverizer
        var state = world.getBlockState(pos);
        if (!state.isOf(PulverizerMod.PULVERIZER_BLOCK) || !state.get(PulverizerBlock.LIT)) {
            this.setDone();
            return;
        }
    }

    @Override
    public boolean shouldAlwaysPlay() {
        // This allows the sound to play even if another sound is at this position
        return true;
    }

    public BlockPos getPos() {
        return pos;
    }
}

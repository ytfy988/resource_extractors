package com.pulverizer.client;

import com.pulverizer.PulverizerMod;
import com.pulverizer.block.AlloyForgeBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class AlloyForgeSoundManager {
    private static final Map<BlockPos, AlloyForgeSoundInstance> activeSounds = new HashMap<>();
    private static final int CHECK_RADIUS = 24;
    private static int tickCounter = 0;
    private static final int SCAN_INTERVAL = 10;

    public static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            activeSounds.clear();
            return;
        }

        tickCounter++;
        
        if (tickCounter % SCAN_INTERVAL != 0) {
            checkExistingSounds(client);
            return;
        }

        World world = client.world;
        BlockPos playerPos = client.player.getBlockPos();

        Set<BlockPos> litForges = new HashSet<>();
        
        for (int x = -CHECK_RADIUS; x <= CHECK_RADIUS; x++) {
            for (int y = -CHECK_RADIUS; y <= CHECK_RADIUS; y++) {
                for (int z = -CHECK_RADIUS; z <= CHECK_RADIUS; z++) {
                    BlockPos checkPos = playerPos.add(x, y, z);
                    var state = world.getBlockState(checkPos);
                    
                    if (state.isOf(PulverizerMod.ALLOY_FORGE_BLOCK) && state.get(AlloyForgeBlock.LIT)) {
                        litForges.add(checkPos);
                    }
                }
            }
        }

        for (BlockPos pos : litForges) {
            if (!activeSounds.containsKey(pos)) {
                AlloyForgeSoundInstance sound = new AlloyForgeSoundInstance(world, pos);
                activeSounds.put(pos, sound);
                client.getSoundManager().play(sound);
            }
        }

        Set<BlockPos> toRemove = new HashSet<>();
        for (Map.Entry<BlockPos, AlloyForgeSoundInstance> entry : activeSounds.entrySet()) {
            BlockPos pos = entry.getKey();
            AlloyForgeSoundInstance sound = entry.getValue();
            
            if (!litForges.contains(pos) || sound.isDone()) {
                toRemove.add(pos);
            }
        }
        
        for (BlockPos pos : toRemove) {
            activeSounds.remove(pos);
        }
    }
    
    private static void checkExistingSounds(MinecraftClient client) {
        Set<BlockPos> toRemove = new HashSet<>();
        
        for (Map.Entry<BlockPos, AlloyForgeSoundInstance> entry : activeSounds.entrySet()) {
            AlloyForgeSoundInstance sound = entry.getValue();
            if (sound.isDone()) {
                toRemove.add(entry.getKey());
            }
        }
        
        for (BlockPos pos : toRemove) {
            activeSounds.remove(pos);
        }
    }

    public static void stopAll() {
        activeSounds.clear();
    }
}

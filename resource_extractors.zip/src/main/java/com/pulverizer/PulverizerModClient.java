package com.pulverizer;

import com.pulverizer.client.AlloyForgeSoundManager;
import com.pulverizer.client.PulverizerSoundManager;
import com.pulverizer.screen.AlloyForgeScreen;
import com.pulverizer.screen.PulverizerScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

public class PulverizerModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HandledScreens.register(PulverizerMod.PULVERIZER_SCREEN_HANDLER, PulverizerScreen::new);
        HandledScreens.register(PulverizerMod.ALLOY_FORGE_SCREEN_HANDLER, AlloyForgeScreen::new);
        
        // Register sound managers
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PulverizerSoundManager.tick(client);
            AlloyForgeSoundManager.tick(client);
        });
    }
}

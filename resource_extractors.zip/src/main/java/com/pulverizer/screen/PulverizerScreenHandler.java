package com.pulverizer.screen;

import com.pulverizer.PulverizerMod;
import com.pulverizer.blockentity.PulverizerBlockEntity;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

public class PulverizerScreenHandler extends ScreenHandler {
    private final Inventory inventory;
    private final PropertyDelegate propertyDelegate;
    private final PulverizerBlockEntity blockEntity;

    public PulverizerScreenHandler(int syncId, PlayerInventory playerInventory) {
        this(syncId, playerInventory, new SimpleInventory(3), new ArrayPropertyDelegate(4));
    }

    public PulverizerScreenHandler(int syncId, PlayerInventory playerInventory, Inventory inventory, PropertyDelegate propertyDelegate) {
        super(PulverizerMod.PULVERIZER_SCREEN_HANDLER, syncId);
        checkSize(inventory, 3);
        this.inventory = inventory;
        this.propertyDelegate = propertyDelegate;
        this.blockEntity = inventory instanceof PulverizerBlockEntity ? (PulverizerBlockEntity) inventory : null;

        inventory.onOpen(playerInventory.player);

        // Input slot
        this.addSlot(new Slot(inventory, PulverizerBlockEntity.INPUT_SLOT, 56, 17) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return PulverizerBlockEntity.isValidInput(stack);
            }
        });

        // Fuel slot - accepts any fuel
        this.addSlot(new Slot(inventory, PulverizerBlockEntity.FUEL_SLOT, 56, 53) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return isFuel(stack) || stack.isOf(Items.BUCKET);
            }
        });

        // Output slot with XP drop
        this.addSlot(new Slot(inventory, PulverizerBlockEntity.OUTPUT_SLOT, 116, 35) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return false;
            }
            
            @Override
            public void onTakeItem(PlayerEntity player, ItemStack stack) {
                super.onTakeItem(player, stack);
                if (blockEntity != null && player.getWorld() instanceof ServerWorld serverWorld) {
                    blockEntity.dropExperience(serverWorld, player.getPos());
                }
            }
        });

        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);

        addProperties(propertyDelegate);
    }

    private static boolean isFuel(ItemStack stack) {
        Integer fuelTime = FuelRegistry.INSTANCE.get(stack.getItem());
        return fuelTime != null && fuelTime > 0;
    }

    public boolean isBurning() {
        return propertyDelegate.get(0) > 0;
    }

    public int getBurnProgress() {
        int burnTime = propertyDelegate.get(0);
        int fuelTime = propertyDelegate.get(1);
        return fuelTime != 0 && burnTime != 0 ? burnTime * 14 / fuelTime : 0;
    }

    public int getCookProgress() {
        int progress = propertyDelegate.get(2);
        int maxProgress = propertyDelegate.get(3);
        return maxProgress != 0 && progress != 0 ? progress * 24 / maxProgress : 0;
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int invSlot) {
        ItemStack newStack = ItemStack.EMPTY;
        Slot slot = this.slots.get(invSlot);

        if (slot != null && slot.hasStack()) {
            ItemStack originalStack = slot.getStack();
            newStack = originalStack.copy();

            if (invSlot < this.inventory.size()) {
                // Moving from machine to player inventory
                if (!this.insertItem(originalStack, this.inventory.size(), this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else {
                // Moving from player inventory to machine
                // Check if it's a valid input
                if (PulverizerBlockEntity.isValidInput(originalStack)) {
                    if (!this.insertItem(originalStack, PulverizerBlockEntity.INPUT_SLOT, PulverizerBlockEntity.INPUT_SLOT + 1, false)) {
                        return ItemStack.EMPTY;
                    }
                }
                // Check if it's a valid fuel
                else if (isFuel(originalStack)) {
                    if (!this.insertItem(originalStack, PulverizerBlockEntity.FUEL_SLOT, PulverizerBlockEntity.FUEL_SLOT + 1, false)) {
                        return ItemStack.EMPTY;
                    }
                }
                // Move between player inventory sections
                else if (invSlot < this.inventory.size() + 27) {
                    if (!this.insertItem(originalStack, this.inventory.size() + 27, this.slots.size(), false)) {
                        return ItemStack.EMPTY;
                    }
                } else if (!this.insertItem(originalStack, this.inventory.size(), this.inventory.size() + 27, false)) {
                    return ItemStack.EMPTY;
                }
            }

            if (originalStack.isEmpty()) {
                slot.setStack(ItemStack.EMPTY);
            } else {
                slot.markDirty();
            }
        }

        return newStack;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return this.inventory.canPlayerUse(player);
    }

    private void addPlayerInventory(PlayerInventory playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(PlayerInventory playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }
    }
}

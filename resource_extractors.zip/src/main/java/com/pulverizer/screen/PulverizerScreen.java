package com.pulverizer.screen;

import com.pulverizer.PulverizerMod;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class PulverizerScreen extends HandledScreen<PulverizerScreenHandler> {
    private static final Identifier TEXTURE = Identifier.of(PulverizerMod.MOD_ID, "textures/gui/pulverizer_gui.png");

    public PulverizerScreen(PulverizerScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
    }

    @Override
    protected void init() {
        super.init();
        titleX = (backgroundWidth - textRenderer.getWidth(title)) / 2;
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;
        
        // Draw main GUI background
        context.drawTexture(TEXTURE, x, y, 0, 0, backgroundWidth, backgroundHeight);
        
        // Draw fire progress (fuel remaining)
        if (handler.isBurning()) {
            int fireHeight = handler.getBurnProgress(); // 0-14
            if (fireHeight > 0) {
                // Draw fire from (176, 0) in texture, height = fireHeight
                // Position on screen: (56, 36) + (14 - fireHeight) to draw from bottom
                context.drawTexture(TEXTURE, 
                    x + 56, 
                    y + 36 + (14 - fireHeight), 
                    176, 
                    14 - fireHeight, 
                    14, 
                    fireHeight);
            }
        }
        
        // Draw arrow progress (cooking)
        int arrowWidth = handler.getCookProgress(); // 0-24
        if (arrowWidth > 0) {
            // Draw arrow from (176, 14) in texture
            // Position on screen: (79, 34)
            context.drawTexture(TEXTURE, 
                x + 79, 
                y + 34, 
                176, 
                14, 
                arrowWidth, 
                17);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        drawMouseoverTooltip(context, mouseX, mouseY);
    }
}

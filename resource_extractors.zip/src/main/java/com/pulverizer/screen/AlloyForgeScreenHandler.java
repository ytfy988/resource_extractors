package com.pulverizer.screen;

import com.pulverizer.PulverizerMod;
import com.pulverizer.blockentity.AlloyForgeBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.world.ServerWorld;

public class AlloyForgeScreenHandler extends ScreenHandler {
    private final Inventory inventory;
    private final PropertyDelegate propertyDelegate;
    private final AlloyForgeBlockEntity blockEntity;

    public AlloyForgeScreenHandler(int syncId, PlayerInventory playerInventory) {
        this(syncId, playerInventory, new SimpleInventory(3), new ArrayPropertyDelegate(4));
    }

    public AlloyForgeScreenHandler(int syncId, PlayerInventory playerInventory, Inventory inventory, PropertyDelegate delegate) {
        super(PulverizerMod.ALLOY_FORGE_SCREEN_HANDLER, syncId);
        checkSize(inventory, 3);
        this.inventory = inventory;
        this.propertyDelegate = delegate;
        this.blockEntity = inventory instanceof AlloyForgeBlockEntity ? (AlloyForgeBlockEntity) inventory : null;

        inventory.onOpen(playerInventory.player);

        // Input slot (56, 17)
        this.addSlot(new Slot(inventory, AlloyForgeBlockEntity.INPUT_SLOT, 56, 17) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return AlloyForgeBlockEntity.isValidInput(stack);
            }
        });

        // Fuel slot (56, 53)
        this.addSlot(new Slot(inventory, AlloyForgeBlockEntity.FUEL_SLOT, 56, 53) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return stack.isOf(Items.COAL) || stack.isOf(Items.CHARCOAL);
            }
        });

        // Output slot (116, 35) with XP drop
        this.addSlot(new Slot(inventory, AlloyForgeBlockEntity.OUTPUT_SLOT, 116, 35) {
            @Override
            public boolean canInsert(ItemStack stack) {
                return false;
            }
            
            @Override
            public void onTakeItem(PlayerEntity player, ItemStack stack) {
                super.onTakeItem(player, stack);
                if (blockEntity != null && player.getWorld() instanceof ServerWorld serverWorld) {
                    blockEntity.dropExperience(serverWorld, player.getPos());
                }
            }
        });

        // Player inventory
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }

        // Player hotbar
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
        }

        addProperties(delegate);
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return this.inventory.canPlayerUse(player);
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int invSlot) {
        ItemStack newStack = ItemStack.EMPTY;
        Slot slot = this.slots.get(invSlot);
        if (slot != null && slot.hasStack()) {
            ItemStack originalStack = slot.getStack();
            newStack = originalStack.copy();
            
            // From forge slots to player inventory
            if (invSlot < 3) {
                if (!this.insertItem(originalStack, 3, 39, true)) {
                    return ItemStack.EMPTY;
                }
            } 
            // From player inventory to forge slots
            else {
                // Try input slot first (iron ingots)
                if (AlloyForgeBlockEntity.isValidInput(originalStack)) {
                    if (!this.insertItem(originalStack, 0, 1, false)) {
                        return ItemStack.EMPTY;
                    }
                }
                // Try fuel slot (coal/charcoal)
                else if (originalStack.isOf(Items.COAL) || originalStack.isOf(Items.CHARCOAL)) {
                    if (!this.insertItem(originalStack, 1, 2, false)) {
                        return ItemStack.EMPTY;
                    }
                }
                // Move between inventory and hotbar
                else if (invSlot < 30) {
                    if (!this.insertItem(originalStack, 30, 39, false)) {
                        return ItemStack.EMPTY;
                    }
                } else if (!this.insertItem(originalStack, 3, 30, false)) {
                    return ItemStack.EMPTY;
                }
            }

            if (originalStack.isEmpty()) {
                slot.setStack(ItemStack.EMPTY);
            } else {
                slot.markDirty();
            }
        }
        return newStack;
    }

    public int getBurnProgress() {
        int progress = this.propertyDelegate.get(2);
        int maxProgress = this.propertyDelegate.get(3);
        return maxProgress != 0 ? progress * 24 / maxProgress : 0;
    }

    public int getFuelProgress() {
        int fuelTime = this.propertyDelegate.get(1);
        if (fuelTime == 0) fuelTime = 200;
        return this.propertyDelegate.get(0) * 14 / fuelTime;
    }

    public boolean isBurning() {
        return this.propertyDelegate.get(0) > 0;
    }
}

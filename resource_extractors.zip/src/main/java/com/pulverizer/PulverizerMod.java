package com.pulverizer;

import com.pulverizer.block.AlloyForgeBlock;
import com.pulverizer.block.PulverizerBlock;
import com.pulverizer.blockentity.AlloyForgeBlockEntity;
import com.pulverizer.blockentity.PulverizerBlockEntity;
import com.pulverizer.screen.AlloyForgeScreenHandler;
import com.pulverizer.screen.PulverizerScreenHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class PulverizerMod implements ModInitializer {
    public static final String MOD_ID = "pulverizer";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Sound
    public static final Identifier PULVERIZER_RUNNING_ID = Identifier.of(MOD_ID, "pulverizer_running");
    public static SoundEvent PULVERIZER_RUNNING_SOUND = SoundEvent.of(PULVERIZER_RUNNING_ID);

    // ===================== PULVERIZER =====================
    public static final Block PULVERIZER_BLOCK = new PulverizerBlock(
            AbstractBlock.Settings.create()
                    .strength(3.5f)
                    .requiresTool()
                    .luminance(state -> state.get(PulverizerBlock.LIT) ? 4 : 0)
    );
    public static final Item PULVERIZER_ITEM = new BlockItem(PULVERIZER_BLOCK, new Item.Settings());
    public static BlockEntityType<PulverizerBlockEntity> PULVERIZER_BLOCK_ENTITY;
    public static ScreenHandlerType<PulverizerScreenHandler> PULVERIZER_SCREEN_HANDLER;

    // Dust Items
    public static final Item RAW_IRON_DUST = new Item(new Item.Settings());
    public static final Item RAW_GOLD_DUST = new Item(new Item.Settings());
    public static final Item RAW_COPPER_DUST = new Item(new Item.Settings());
    public static final Item SAND_DUST = new Item(new Item.Settings());

    // ===================== ALLOY FORGE =====================
    public static final Block ALLOY_FORGE_BLOCK = new AlloyForgeBlock(
            AbstractBlock.Settings.create()
                    .strength(3.5f)
                    .requiresTool()
                    .luminance(state -> state.get(AlloyForgeBlock.LIT) ? 13 : 0)
    );
    public static final Item ALLOY_FORGE_ITEM = new BlockItem(ALLOY_FORGE_BLOCK, new Item.Settings());
    public static BlockEntityType<AlloyForgeBlockEntity> ALLOY_FORGE_BLOCK_ENTITY;
    public static ScreenHandlerType<AlloyForgeScreenHandler> ALLOY_FORGE_SCREEN_HANDLER;

    // ===================== STEEL =====================
    public static final Item STEEL_INGOT = new Item(new Item.Settings());
    public static final Item STEEL_NUGGET = new Item(new Item.Settings());
    
    // Steel Block
    public static final Block STEEL_BLOCK = new Block(
            AbstractBlock.Settings.create()
                    .strength(5.0f, 6.0f)
                    .requiresTool()
                    .sounds(BlockSoundGroup.METAL)
    );
    public static final Item STEEL_BLOCK_ITEM = new BlockItem(STEEL_BLOCK, new Item.Settings());

    // Steel Tools
    public static Item STEEL_SWORD;
    public static Item STEEL_PICKAXE;
    public static Item STEEL_AXE;
    public static Item STEEL_SHOVEL;
    public static Item STEEL_HOE;

    // Steel Armor
    public static RegistryEntry<ArmorMaterial> STEEL_ARMOR_MATERIAL;
    public static Item STEEL_HELMET;
    public static Item STEEL_CHESTPLATE;
    public static Item STEEL_LEGGINGS;
    public static Item STEEL_BOOTS;

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Pulverizer Mod!");

        // Register Sound
        Registry.register(Registries.SOUND_EVENT, PULVERIZER_RUNNING_ID, PULVERIZER_RUNNING_SOUND);

        // ===================== REGISTER PULVERIZER =====================
        Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "pulverizer"), PULVERIZER_BLOCK);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "pulverizer"), PULVERIZER_ITEM);
        
        PULVERIZER_BLOCK_ENTITY = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                Identifier.of(MOD_ID, "pulverizer"),
                BlockEntityType.Builder.create(PulverizerBlockEntity::new, PULVERIZER_BLOCK).build()
        );

        PULVERIZER_SCREEN_HANDLER = Registry.register(
                Registries.SCREEN_HANDLER,
                Identifier.of(MOD_ID, "pulverizer"),
                new ScreenHandlerType<>(PulverizerScreenHandler::new, FeatureFlags.VANILLA_FEATURES)
        );

        // Register Dust Items
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "raw_iron_dust"), RAW_IRON_DUST);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "raw_gold_dust"), RAW_GOLD_DUST);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "raw_copper_dust"), RAW_COPPER_DUST);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "sand_dust"), SAND_DUST);

        // ===================== REGISTER ALLOY FORGE =====================
        Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "alloy_forge"), ALLOY_FORGE_BLOCK);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "alloy_forge"), ALLOY_FORGE_ITEM);

        ALLOY_FORGE_BLOCK_ENTITY = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                Identifier.of(MOD_ID, "alloy_forge"),
                BlockEntityType.Builder.create(AlloyForgeBlockEntity::new, ALLOY_FORGE_BLOCK).build()
        );

        ALLOY_FORGE_SCREEN_HANDLER = Registry.register(
                Registries.SCREEN_HANDLER,
                Identifier.of(MOD_ID, "alloy_forge"),
                new ScreenHandlerType<>(AlloyForgeScreenHandler::new, FeatureFlags.VANILLA_FEATURES)
        );

        // ===================== REGISTER STEEL ITEMS =====================
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_ingot"), STEEL_INGOT);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_nugget"), STEEL_NUGGET);
        Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "steel_block"), STEEL_BLOCK);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_block"), STEEL_BLOCK_ITEM);

        // ===================== REGISTER STEEL TOOLS =====================
        ToolMaterial steelMaterial = SteelToolMaterial.INSTANCE;
        
        STEEL_SWORD = new SwordItem(steelMaterial, new Item.Settings()
                .attributeModifiers(SwordItem.createAttributeModifiers(steelMaterial, 3, -2.4f)));
        
        STEEL_PICKAXE = new PickaxeItem(steelMaterial, new Item.Settings()
                .attributeModifiers(PickaxeItem.createAttributeModifiers(steelMaterial, 1.0f, -2.8f)));
        
        STEEL_AXE = new AxeItem(steelMaterial, new Item.Settings()
                .attributeModifiers(AxeItem.createAttributeModifiers(steelMaterial, 4.5f, -3.05f)));
        
        STEEL_SHOVEL = new ShovelItem(steelMaterial, new Item.Settings()
                .attributeModifiers(ShovelItem.createAttributeModifiers(steelMaterial, 1.5f, -3.0f)));
        
        STEEL_HOE = new HoeItem(steelMaterial, new Item.Settings()
                .attributeModifiers(HoeItem.createAttributeModifiers(steelMaterial, -2.0f, -0.5f)));

        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_sword"), STEEL_SWORD);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_pickaxe"), STEEL_PICKAXE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_axe"), STEEL_AXE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_shovel"), STEEL_SHOVEL);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_hoe"), STEEL_HOE);

        // ===================== REGISTER STEEL ARMOR =====================
        Map<ArmorItem.Type, Integer> defenseMap = Map.of(
                ArmorItem.Type.BOOTS, 3,
                ArmorItem.Type.LEGGINGS, 6,
                ArmorItem.Type.CHESTPLATE, 8,
                ArmorItem.Type.HELMET, 3,
                ArmorItem.Type.BODY, 11
        );
        
        Supplier<Ingredient> repairIngredient = () -> Ingredient.ofItems(STEEL_INGOT);
        
        List<ArmorMaterial.Layer> layers = List.of(
                new ArmorMaterial.Layer(Identifier.of(MOD_ID, "steel"))
        );
        
        ArmorMaterial steelArmorMaterial = new ArmorMaterial(
                defenseMap,
                10,  // Enchantability: Iron=9, Diamond=10, so steel matches diamond
                SoundEvents.ITEM_ARMOR_EQUIP_IRON,
                repairIngredient,
                layers,
                1.0f,
                0.0f
        );
        
        STEEL_ARMOR_MATERIAL = Registry.registerReference(
                Registries.ARMOR_MATERIAL,
                Identifier.of(MOD_ID, "steel"),
                steelArmorMaterial
        );

        int durabilityMultiplier = 20;
        
        STEEL_HELMET = new ArmorItem(STEEL_ARMOR_MATERIAL, ArmorItem.Type.HELMET, 
                new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(durabilityMultiplier)));
        STEEL_CHESTPLATE = new ArmorItem(STEEL_ARMOR_MATERIAL, ArmorItem.Type.CHESTPLATE, 
                new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(durabilityMultiplier)));
        STEEL_LEGGINGS = new ArmorItem(STEEL_ARMOR_MATERIAL, ArmorItem.Type.LEGGINGS, 
                new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(durabilityMultiplier)));
        STEEL_BOOTS = new ArmorItem(STEEL_ARMOR_MATERIAL, ArmorItem.Type.BOOTS, 
                new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(durabilityMultiplier)));

        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_helmet"), STEEL_HELMET);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_chestplate"), STEEL_CHESTPLATE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_leggings"), STEEL_LEGGINGS);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "steel_boots"), STEEL_BOOTS);

        // ===================== CREATIVE TABS =====================
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(PULVERIZER_ITEM);
            entries.add(ALLOY_FORGE_ITEM);
        });
        
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> {
            entries.add(STEEL_BLOCK_ITEM);
        });
        
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(RAW_IRON_DUST);
            entries.add(RAW_GOLD_DUST);
            entries.add(RAW_COPPER_DUST);
            entries.add(SAND_DUST);
            entries.add(STEEL_INGOT);
            entries.add(STEEL_NUGGET);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(STEEL_PICKAXE);
            entries.add(STEEL_AXE);
            entries.add(STEEL_SHOVEL);
            entries.add(STEEL_HOE);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(STEEL_SWORD);
            entries.add(STEEL_HELMET);
            entries.add(STEEL_CHESTPLATE);
            entries.add(STEEL_LEGGINGS);
            entries.add(STEEL_BOOTS);
        });

        LOGGER.info("Pulverizer Mod initialized!");
    }
}

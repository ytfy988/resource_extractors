package com.pulverizer;

import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;

public class SteelToolMaterial implements ToolMaterial {
    public static final SteelToolMaterial INSTANCE = new SteelToolMaterial();

    @Override
    public int getDurability() {
        return 956; // Between iron (250) and diamond (1561)
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 7.0f; // Between iron (6.0) and diamond (8.0)
    }

    @Override
    public float getAttackDamage() {
        return 2.5f; // Between iron (2.0) and diamond (3.0)
    }

    @Override
    public TagKey<Block> getInverseTag() {
        return BlockTags.INCORRECT_FOR_IRON_TOOL; // Same mining level as iron
    }

    @Override
    public int getEnchantability() {
        return 12; // Between iron (14) and diamond (10) - good middle ground
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(PulverizerMod.STEEL_INGOT);
    }
}
